-- DBConnection class as Singleton
-- Stratgy Pattern class as Attendance from login and mannual.
-- Builder pattern added using interfaces like attendance.
-- Facade interface example is CommonUtility class which allows you to decouple your class and allows any JTable to be used with the class for searching, table populating.
-- GenericDAO interface provides functionality for the Template Driven template
-- GenericDAO interface is same for the decorator pattern as it has all CRUD operations along with that the implementing classes can extend the functionality and put their own methods as well.
-- CommonMethods acts as a Flywight object as it does not creates new object every time and the same methods are used everytime you want to use methods like searching from table,
   populating table or fill comboboxes in any JFrame.